import Foundation

// SISTEMA PARA GESTIONAR RESERVAS DE HOTEL LUCHADORES

// Struct de cliente
struct Client: Equatable, Hashable {
    let name: String
    let age: Int
    let hight: Double
}

// Struct que define las propiedades de la reserva
struct Reservation: Equatable, Hashable {
    let ID = UUID()
    let name: String
    let listClients: [Client]
    let duration: Int
    var prize: Double
    let breackfast: Bool
}

// Enumerado que detalla los errores

enum ReservationError: Error {
    case idRepeated
    case clientResertvationFounded
    case notFoundReservation
}

// clase manager que se encarga de la gestión de las reservas

final class HotelReservationManager {
    
    var reservations: [Reservation] = []
    
    // Función que calcula el precio de las reservas teniendo en cuenta número de personas, duración y si incluye o no el desayuno
    func calcPrize(_ numPersons: Int, _ duration: Int, _ breackfast: Bool) -> Double {
        let breackfastPrize = breackfast ? 1.25 : 1
        return Double(20 * numPersons * duration) * breackfastPrize
    }
    
    // Función para crear una reserva que a au vez llama  al afunción que calcula el precio
    func createReservation(name: String, clients: [Client], duration: Int, breakfast: Bool) -> Reservation {
        let prize = calcPrize(clients.count, duration, breakfast)
        return Reservation(name: name, listClients: clients, duration: duration, prize: prize, breackfast: breakfast)
        
    }
    
    // Funcion que comprueba, antes de añadir la reserva al array de reservas, que el ID no está repetido y que ninguno de los nuevos clientes aparece ya en otra reserva
    func checkReservation(reservation: Reservation) throws {
        guard !reservations.contains(where: { $0.ID == reservation.ID }) else {
            print("No se puede añadir porque el ID \(reservation.ID) ya existe")
            throw ReservationError.idRepeated
        }
        
        for eachReservation in reservations {
            for client in eachReservation.listClients {
                if reservation.listClients.contains(where: { $0.name == client.name }) {
                    print("No se puede añadir porque \(client.name) ya existe")
                    throw ReservationError.clientResertvationFounded
                }
            }
        }
        reservations.append(reservation)
    }
    
    // Función que muestra las reservas
    func showReservation() {
        for reservation in reservations {
            print("////------\(reservation.name)-------/////")
            print("El ID de la reserva es:", reservation.ID, "\nDuración de la reserva:", reservation.duration, "\nClientes de la reserva:", reservation.listClients, "\nPrecio reserva: ", reservation.prize, "\nDuración en noches:", reservation.duration, "\n")
        }
    }
    
    // Función que elimina una reserva a partir de un ID introducido
    func deleteReservation (checkID: UUID) throws {
        print("Eliminando la reserva: \(checkID)...")
        for reservation in reservations {
            if reservation.ID == checkID {
                reservations.removeAll { $0.ID == checkID }
                print("La reserva: \(checkID) ha sido eliminada")
                showReservation()
                return
            } else {
                print("No se puede eliminar porque \(checkID) no existe")
                throw ReservationError.notFoundReservation
            }
        }
    }
    
    
}
// Creación de os objetos manager, cliente, reserva

let reservationManager = HotelReservationManager()

let client1 = Client(name: "Goku", age: 26, hight: 187)
let client2 = Client(name: "Piccolo", age: 44, hight: 205)
let client3 = Client(name: "Bulma", age: 28, hight: 168)

let client4 = Client(name: "Krilin", age: 27, hight: 150)
let client5 = Client(name: "Chi Chi", age: 24, hight: 152)
let client6 = Client(name: "Vegeta", age: 40, hight: 175)

let client7 = Client(name: "Freezer", age: 123, hight: 123)
let client8 = Client(name: "Trunks", age: 15, hight: 178)
let client9 = Client(name: "Mr Satán", age: 200, hight: 210)

let client10 = Client(name: "Ten Shin Han", age: 37, hight: 190)
let client11 = Client(name: "Celula", age: 50, hight: 180)
let client12 = Client(name: "Gotenks", age: 50, hight: 180)


// Por ultimo código para realizar comprobaciónes, ver el listado de reservas y eliminar una reserva

func testAddreservation(reserv: Reservation) throws {
    let newReserv = reservationManager.createReservation(name: reserv.name, clients: reserv.listClients, duration: reserv.duration, breakfast: reserv.breackfast)
    try reservationManager.checkReservation(reservation: newReserv)
    reservationManager.showReservation()
}
func testCancelReservation(reservationID: UUID) throws{
    try reservationManager.deleteReservation(checkID: reservationID)
}

func testReservationPrize() throws {
    try testAddreservation(reserv: reservationManager.createReservation(name: "Hotel Cancún",
                                                                        clients: [client7, client8, client9],
                                                                        duration: 2,
                                                                        breakfast: true))
    
    
    
    try testAddreservation(reserv: reservationManager.createReservation(name: "Hotel Bahamas",
                                                                        clients: [client1, client2, client3],
                                                                        duration: 2,
                                                                        breakfast: true))
}

try testAddreservation(reserv: reservationManager.createReservation(name: "Hotel Cancún",
                                                                    clients: [client7, client8, client9],
                                                                    duration: 2,
                                                                    breakfast: true))



try testAddreservation(reserv: reservationManager.createReservation(name: "Hotel Bahamas",
                                                    clients: [client1, client2, client3],
                                                    duration: 3,
                                                    breakfast: true))

try testAddreservation(reserv: reservationManager.createReservation(name: "Hotel Cancún",
                                                    clients: [client7, client5, client12],
                                                    duration: 5,
                                                    breakfast: true))

//try testCancelReservation(reservationID: UUID(uuidString: "02DF7A88-D6A3-4C27-90C8-BD0CA42F80CB")!)

//try testReservationPrize()
